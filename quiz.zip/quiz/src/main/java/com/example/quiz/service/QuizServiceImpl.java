package com.example.quiz.service;

import com.example.quiz.QuizApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class QuizServiceImpl implements QuizService{

    private static final Logger log =
            LoggerFactory.getLogger(QuizApplication.class);

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }

    @Override
    public String getQuiz(RestTemplate restTemplate) {
        ResponseEntity<Quiz[]> response =
                restTemplate.getForEntity(
                        "https://opentdb.com/api.php?amount=5&category=11",
                        Quiz[].class);
        Quiz[] quiz = response.getBody();

       // return args -> {
//            Quiz quiz = restTemplate.getForObject(
//                    "https://opentdb.com/api.php?amount=5&category=11",
//                    Quiz.class);
            log.info(quiz.toString());
            return quiz.toString();
      //  };
    }
}
