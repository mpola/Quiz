package com.example.quiz.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Quiz extends Results{
    private String category;
    private Results results;

    public Quiz() {
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Results getResult() {
        return results;
    }

    public void setResult(Results results) {
        this.results = results;
    }

    @Override
    public String toString() {
        return "Quiz{" +
                "category='" + category + '\'' +
                ", result=" + results +
                '}';
    }
}
