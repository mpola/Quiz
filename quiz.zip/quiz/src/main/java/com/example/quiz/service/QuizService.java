package com.example.quiz.service;

import org.springframework.web.client.RestTemplate;

public interface QuizService {
    public String getQuiz(RestTemplate restTemplate);
}
