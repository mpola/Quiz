package com.example.quiz;

import com.example.quiz.service.Quiz;

import com.example.quiz.service.QuizService;
import com.example.quiz.service.QuizServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class QuizApplication {

	private static final Logger log =
			LoggerFactory.getLogger(QuizApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(QuizApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	QuizService quizService = new QuizServiceImpl();

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
		return args -> quizService.getQuiz(restTemplate);
	}

}
